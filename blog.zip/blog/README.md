Creating a blog from scratch with PHP - Part 5 Sidebar, Categories and Archives
=============

These files acompany the tutorial: [Creating a blog from scratch with PHP - Part 5 Sidebar, Categories and Archives](http://daveismyname.com/creating-a-blog-from-scratch-with-php-part-5-sidebar-categories-and-archives-bp)
